/*
 *  test_classifiers.h
 *  FoodcamClassifier
 *
 *  Created by Roy Shilkrot on 8/20/11.
 *  Copyright 2011 MIT. All rights reserved.
 *
 */

#include "predict_common.h"